﻿namespace AnalyzerTests
{
    public class Class1
    {

        private string unused_reference;
        private string unused_declaration = string.Empty;

    }
}