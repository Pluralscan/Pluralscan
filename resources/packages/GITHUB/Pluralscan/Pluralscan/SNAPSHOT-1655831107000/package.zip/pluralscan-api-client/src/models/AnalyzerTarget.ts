enum AnalyzerTarget {
    Package = 'package',
    Source = 'source',
    Dll = 'dll',
    Docker = 'docker'
}