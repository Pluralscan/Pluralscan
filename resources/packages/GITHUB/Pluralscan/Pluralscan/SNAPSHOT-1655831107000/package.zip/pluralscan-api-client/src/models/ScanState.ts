export enum ScanState {
    SCHEDULED,
    RUNNING,
    COMPLETED,
    CANCELLED,
    ERROR
}