export interface Package {
    id: string;
    name: string;
    created: string;
    origin: string;
}