export enum ProjectSource {
    LOCAL = "local",
    GIT = "git",
    GITHUB = "github",
    GITLAB = "gitlab",
    BITBUCKET = "bitbucket",
}