export enum ExecutablePlatform {
    Internal = "internal",
    Windows = 'win_exe',
    Dotnet = 'dotnet'
}