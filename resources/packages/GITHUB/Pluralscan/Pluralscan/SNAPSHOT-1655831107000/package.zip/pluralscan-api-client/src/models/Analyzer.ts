export interface Analyzer {
    id: string;
    name: string;
}