import { Language } from "./Language";

export interface Technology {
    name: string;
    version: string;
    language: Language
}