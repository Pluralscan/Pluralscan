export interface Dependency {
    id: string;
    name: string;
    created: string;
    origin: string;
}