# Pluralscan - TS Api Client

## Build

```
npm run build
```

Output directory: pluralscan-webapp/frontend/libs/dist
