import { writable } from "svelte/store";

export const rightPanel = writable({});
export const leftPanel = writable({});
