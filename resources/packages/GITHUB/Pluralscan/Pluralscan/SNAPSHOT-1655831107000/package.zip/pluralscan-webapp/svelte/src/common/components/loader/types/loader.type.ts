export type LoaderTypes = {
    size: string | number
    color: string
    unit: string
    duration: string
  }