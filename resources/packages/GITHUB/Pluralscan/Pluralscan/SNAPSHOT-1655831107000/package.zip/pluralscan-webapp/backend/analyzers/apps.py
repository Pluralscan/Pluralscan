from django.apps import AppConfig


class AnalyzersConfig(AppConfig):
    """AnalyzersConfig"""
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'analyzers'
