# from django.urls import reverse

# from rest_framework.test import APITestCase


# class AnalyzerViewSetTestCase(APITestCase):
#     url = reverse("package_info")

#     def test_package_info(self):
#         response = self.client.post(self.url, {})
#         self.assertEqual(400, response.status_code)
