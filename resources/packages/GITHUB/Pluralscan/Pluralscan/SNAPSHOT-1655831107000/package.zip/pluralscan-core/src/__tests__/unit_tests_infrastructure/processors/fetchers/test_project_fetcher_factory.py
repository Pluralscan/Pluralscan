from pluralscan.domain.projects.project_source import ProjectSource
from pluralscan.infrastructure.processor.fetchers.projects.project_fetcher_factory import \
    ProjectFetcherFactory


def test_create():
    pass