# CleanSecPy - Core Packages

## Domain

## Infrastructure

The infrastructure package provides various adapters for technology implementation's which are required by **client applications**
for process business logic.