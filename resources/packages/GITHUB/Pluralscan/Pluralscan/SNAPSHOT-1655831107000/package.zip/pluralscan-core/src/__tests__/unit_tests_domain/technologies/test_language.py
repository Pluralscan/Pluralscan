import pytest
from pluralscan.domain.technologies.technology import Technology
