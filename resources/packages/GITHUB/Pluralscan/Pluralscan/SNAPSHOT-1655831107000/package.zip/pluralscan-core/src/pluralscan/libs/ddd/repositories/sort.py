class Sort:
    def __init__(self) -> None:
        pass