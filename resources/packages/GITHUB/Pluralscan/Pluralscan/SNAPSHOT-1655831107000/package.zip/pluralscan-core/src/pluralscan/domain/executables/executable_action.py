from enum import Enum


class ExecutableAction(Enum):
    SCAN = "scan"
    FIX = "fix"
