https://www.mongodb.com/docs/drivers/python/
https://pymongo.readthedocs.io/en/stable/api/index.html
https://pymongo.readthedocs.io/en/stable/tutorial.html