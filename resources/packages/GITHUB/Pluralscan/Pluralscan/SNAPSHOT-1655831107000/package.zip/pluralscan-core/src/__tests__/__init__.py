import os
import sys

fpath = os.path.join(os.path.dirname(__file__))
sys.path.append(fpath)
print(sys.path)