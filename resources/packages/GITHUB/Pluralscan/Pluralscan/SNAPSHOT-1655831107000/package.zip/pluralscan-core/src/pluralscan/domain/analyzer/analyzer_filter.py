class AnalyzerFilter:
    def __init__(self) -> None:
        pass
