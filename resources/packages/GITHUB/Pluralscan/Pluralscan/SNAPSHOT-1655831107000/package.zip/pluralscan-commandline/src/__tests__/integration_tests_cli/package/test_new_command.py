import unittest


class TestNewCommandUseCase(unittest.TestCase):
    """TestNewCommandUseCase"""
    def setUp(self):
        pass

    def test_new(self):
        """test_new"""
        # Arrange
        packgage_url = "https://github.com/esakik/parrot-backend/archive/refs/heads/master.zip"

        # Act
        #package_cli = package.new("Cast", url=packgage_url, description="")

        # Assert
        #self.assertTrue(package_cli)
