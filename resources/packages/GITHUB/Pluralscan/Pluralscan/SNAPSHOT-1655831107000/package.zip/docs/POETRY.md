# Poetry

## Setup
https://python-poetry.org/docs/master/#installing-with-the-official-installer
### Windows

(Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content | py -
