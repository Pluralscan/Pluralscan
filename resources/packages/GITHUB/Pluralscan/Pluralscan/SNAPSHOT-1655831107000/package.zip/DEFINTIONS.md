# Pluralscan - Important Definitions

- **SCA**: Software Composition Analysis
- **SAST**: Static Application Security Testing (SAST) Tools, can help analyze source code or compiled versions of code to help find security flaws. **SAST tools can be added into your IDE**. Such tools can help you detect issues during software development. SAST tool feedback can save time and effort, especially when compared to finding vulnerabilities later in the development cycle.
- **RASP**: 
- **DAST**:
- **IAST**: