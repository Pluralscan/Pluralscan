<!-- To understand how Svelte Kit handle layouts, read docs at https://kit.svelte.dev/docs/layouts -->
<script>
	import 'carbon-components-svelte/css/white.css';
</script>

<slot />
