﻿// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("52dce73d-148d-47e1-a595-9eada6b3b7c5")]

[assembly: InternalsVisibleTo("Sarif.Viewer.VisualStudio.ResultSources.GitHubAdvancedSecurity.UnitTests")]
