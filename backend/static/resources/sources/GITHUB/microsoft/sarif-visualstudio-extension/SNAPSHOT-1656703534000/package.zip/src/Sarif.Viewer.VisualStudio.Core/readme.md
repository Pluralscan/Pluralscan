﻿How to Debug
============

Set the following values in the Sarif.Viewer.VisualStudio project's Debug property page

Start external program: C:\Program Files (x86)\Microsoft Visual Studio 14.0\Common7\IDE\devenv.exe
Command line arguments: /rootsuffix Exp /Command "Tools.OpenSARIFfile E:\Path\To\Sarif\log.sarif"
