__version__ = '1.1.3'

default_app_config = 'scheduler.apps.SchedulerConfig'
